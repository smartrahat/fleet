@extends('layouts.admin')
@section('content')
    <div class="inner-wrapper" style="margin-top: -700px;;">
        <section role="main" class="content-body">
            <h2>Welcome Fleet Management Software</h2>
        </section>
    </div>

@endsection