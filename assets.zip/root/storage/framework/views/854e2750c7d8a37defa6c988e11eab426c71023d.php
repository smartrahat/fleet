<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <header class="page-header">
                <h2>Dashboard</h2>
                <div class="right-wrapper pull-right">
                    <ol class="breadcrumbs">
                        <li>
                            <a>
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li><span>Dashboard</span></li>
                    </ol>
                    <a class="sidebar-right-toggle" ><i class="fa fa-chevron-left"></i></a>
                </div>
            </header>
            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Status of Vehicle</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::model(['action'=>'StatusController@store','method'=>'post','class'=>'form-horizontal'])); ?>

                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Status Name:', ['class'=>'col-md-3 control-label'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('description','Description:',['class'=>'col-md-3 control-label'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-2 col-md-offset-3">
                                    <input type="submit" value="Save"  class="form-control btn btn-success">
                                </div>
                                <div class="col-md-2">
                                    <input type="reset" value="Reset"  class="form-control btn btn-warning">
                                </div>
                                <div class="col-md-2">
                                    <input type="Button" value="Cancel"  class="form-control btn btn-danger">
                                </div>
                            </div>
                            <!-- ends-->
                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Status of Vehicle</h2>
                        </header>

                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-condensed mb-none">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($status->id); ?></td>
                                            <td><?php echo e($status->name); ?></td>
                                            <td><?php echo e($status->desctiption); ?></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                </div>
            </div>

        </section>
    <!-- end: page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>