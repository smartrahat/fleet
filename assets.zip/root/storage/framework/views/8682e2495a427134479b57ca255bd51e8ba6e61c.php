<?php $__env->startSection('content'); ?>
    <div class="inner-wrapper">
        <section role="main" class="content-body">

            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Vehicle Information Form</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::open(array('action' => 'VehicleController@store','method'=>'post'))); ?>

                            <!-- Vehicle Name Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Name', array('class'=>'col-md-3 control-lebel'))); ?>

                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('name', '', array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Vehicle name ends-->
                            <!-- brand Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Brand Name', array('class'=>'col-md-3 control-lebel'))); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('brand_name',$repository->brands(),null,['class'=>'form-control populate','data-plugin-selectTwo'])); ?>

                                </div>
                            </div>
                            <!-- brand ends-->
                            <!-- Type start-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Types', array('class'=>'col-md-3 control-lebel'))); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('type',$repository->types(),null,['class'=>'form-control populate','data-plugin-selectTwo'])); ?>

                                </div>
                            </div>
                            <!-- Types ends-->
                            <!-- Owner start-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Owner Name', array('class'=>'col-md-3 control-lebel'))); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::select('owner_name',$repository->owners(),null,['class'=>'form-control populate','data-plugin-selectTwo'])); ?>

                                </div>
                            </div>
                            <!-- Owner ends-->
                            <!--Road permit starts-->
                            <div class="form-group">
                                <label class="col-md-3 control-label">Road Permit</label>
                                <div class="col-md-6">
                                    <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd' data-date-format='yyyy-mm-dd'>
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
                                        <?php echo e(Form::text('roadPermitStart', null, array('class' => 'form-control'))); ?>

                                        
                                        <span class="input-group-addon">to</span>
                                        <?php echo e(Form::text('roadPermitEnd', null, array('class' => 'form-control'))); ?>

                                        
                                    </div>
                                </div>
                            </div>
                            <!--Road permit ends-->

                            <!--Tax Token starts-->
                            <div class="form-group">
                                <label class="col-md-3 control-label">Tax Token</label>
                                <div class="col-md-6">
                                    <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
                                        <?php echo e(Form::text('taxTokenStart', null, array('class' => 'form-control'))); ?>

                                        <span class="input-group-addon">to</span>
                                        <?php echo e(Form::text('taxTokenEnd', null, array('class' => 'form-control'))); ?>

                                    </div>
                                </div>
                            </div>
                            <!--Road permit ends-->
                            <!--Road permit starts-->
                            <div class="form-group">
                                <label class="col-md-3 control-label">Insurance</label>
                                <div class="col-md-6">
                                    <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
                                        <?php echo e(Form::text('insuranceStart', null, array('class' => 'form-control'))); ?>

                                        <span class="input-group-addon">to</span>
                                        <?php echo e(Form::text('insuranceEnd', null, array('class' => 'form-control'))); ?>

                                    </div>
                                </div>
                            </div>
                            <!--Road permit ends-->

                            <!--Fitness starts-->
                            <div class="form-group">
                                <label class="col-md-3 control-label">Fitness</label>
                                <div class="col-md-6">
                                    <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
                                        <?php echo e(Form::text('fitnessStart', null, array('class' => 'form-control'))); ?>

                                        <span class="input-group-addon">to</span>
                                        <?php echo e(Form::text('fitnessEnd', null, array('class' => 'form-control'))); ?>

                                    </div>
                                </div>
                            </div>
                            <!--Fitness ends-->

                            <!--Registration Certificate starts-->
                            <div class="form-group">
                                <label class="col-md-3 control-label">Registration Certification</label>
                                <div class="col-md-6">
                                    <div class="input-daterange input-group" data-plugin-datepicker data-date-format='yyyy-mm-dd'>
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
                                        <?php echo e(Form::text('regCertStart', null, array('class' => 'form-control'))); ?>

                                        <span class="input-group-addon">to</span>
                                        <?php echo e(Form::text('regCertEnd', null, array('class' => 'form-control'))); ?>                                    </div>
                                </div>
                            </div>
                            <!--Registration Certificate ends-->

                            <!-- Vehicle Number Starts-->
                            <div class="form-group">

                                <label class="col-md-3 control-label">Vehicle Number</label>
                                <div class="col-md-6">
                                    <?php echo e(Form::text('vehicleNo', '', array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Vehicle number ends-->

                            <!-- Engine Number Starts-->
                            <div class="form-group">

                                <label class="col-md-3 control-label">Engine Number</label>
                                <div class="col-md-6">
                                    <?php echo e(Form::text('engineNo', '', array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Engine Number ends-->

                            <!-- Chesis Number Starts-->
                            <div class="form-group">

                                <label class="col-md-3 control-label">Chases Number</label>
                                <div class="col-md-6">
                                    <?php echo e(Form::text('chasesNo', '', array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Chesis Number ends-->

                            <!-- Status Starts-->
                            <div class="form-group">
                                <label class="col-md-3 control-label">Status</label>
                                <div class="col-md-6">
                                    <?php echo e(Form::select('status',$repository->status(),null,['class'=>'form-control populate','data-plugin-selectTwo'])); ?>

                                </div>
                            </div>
                            <!-- Status ends-->
                            <!--Submit button -->
                            <div class="form-group">
                                <div class="col-md-2 col-md-offset-3">
                                    <input type="submit" value="Save"  class="form-control btn btn-success">
                                </div>
                                <div class="col-md-2">
                                    <input type="Button" value="Reset"  class="form-control btn btn-warning">
                                </div>
                                <div class="col-md-2">
                                    <input type="Button" value="Cencel"  class="form-control btn btn-danger">
                                </div>
                            </div>
                            <!-- ends-->

                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </section>
    </div>
    </div>
    <!-- end: page -->
    </section>
    </div>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>