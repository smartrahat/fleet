<?php $__env->startSection('content'); ?>
        <section role="main" class="content-body">
            <!-- start: page -->
            <div class="row">
                <div class="col-xs-12">
                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
                            </div>
                            <h2 class="panel-title">Employee Information Form</h2>
                        </header>

                        <div class="panel-body">
                            <?php echo e(Form::model($employee,['action'=>['EmployeeController@update',$employee->id],'method'=>'patch','class'=>'form-horizontal'])); ?>

                            <!-- Owner Name Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Name', array('class'=>'col-md-3 control-label'))); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('name', null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Owner name ends-->

                            <!-- Owner Father's Name Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Father\'s Name', array('class'=>'col-md-3 control-label'))); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('f_name',null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Owner Father's name ends-->

                            <!-- Address Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Address', array('class'=>'col-md-3 control-label'))); ?>

                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('address',null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Address ends-->

                            <!-- NID Number Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'National ID No', array('class'=>'col-md-3 control-label'))); ?>

                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('nid_no',null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- NID Number ends-->

                            <!-- Email Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'E-mail', array('class'=>'col-md-3 control-label'))); ?>

                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('email',null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Email ends-->

                            <!-- Owner Name Starts-->
                            <div class="form-group">
                                <?php echo e(Form::label('name', 'Contact Number', array('class'=>'col-md-3 control-label'))); ?>

                                
                                <div class="col-md-6">
                                    <?php echo e(Form::text('mobile_no', null, array('class' => 'form-control'))); ?>

                                </div>
                            </div>
                            <!-- Owner name ends-->


                            <div class="form-group">
                                <div class="col-md-2 col-md-offset-3">
                                    <input type="submit" value="Update"  class="form-control btn btn-success">
                                </div>
                                <div class="col-md-2">
                                    <input type="reset" value="Reset"  class="form-control btn btn-warning">
                                </div>
                                <div class="col-md-2">
                                    <input type="Button" value="Cancel"  class="form-control btn btn-danger">
                                </div>
                            </div>
                            <!-- ends-->
                            <?php echo e(Form::close()); ?>

                        </div>
                    </section>
                </div>
            </div>
        </section>
    </div>
    <!-- end: page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>